#' pflamelet: Persistence Flamelets
#'
#'
#' @docType package
#' @name pflamelet
#' @importFrom TDA gridDiag kde landscape silhouette
NULL
